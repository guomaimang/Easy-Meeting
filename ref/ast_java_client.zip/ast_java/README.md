前置说明：
本示例通过maven插件集成protobuf能力，原生协议文件置于src/main/protos目录下，pom文件定义了插件和依赖，运行mvn compile编译后将自动生成于target/generated-sources/protobuf目录下，用户可按照自己的生成内容所在目录修改Main中的引用：
import data.speech.ast.AstService;
import data.speech.understanding.AuBase;
import data.speech.common.Rpcmeta;
import data.speech.event.Events;

功能运行[注意按照自己资源和密钥修改对应参数值]
mvn clean compile exec:java -Dexec.mainClass=demo.Main -Dexec.args="--target=ast --host=wss://openspeech.bytedance.com --endpoint=api/v4/ast/v2/translate --resource_id=volc.service_type.10053 --app_key=1111111 --access_key=2222222 --audio_file=test_audio.wav --outdir=. --chunk_size=3200"

启动后将开始执行相关逻辑，最终将得到最终文本和音频输出


