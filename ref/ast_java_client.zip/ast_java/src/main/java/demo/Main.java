package demo;

import okhttp3.*;
import okio.ByteString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import data.speech.ast.AstService;
import data.speech.understanding.AuBase;
import data.speech.common.Rpcmeta;
import data.speech.event.Events;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;

public class Main {

    public static void main(String[] args) throws Exception {
        // 默认参数
        String target = "ast";
        String host = "wss://openspeech.bytedance.com";
        String endpoint = "api/v4/ast/v2/translate";
        String resourceId = "volc.service_type.10053";
        String appKey = "";
        String accessKey = "";
        String audioFile = "test_audio.wav";
        String outdir = ".";
        int chunkSize = 3200;

        // 支持命令行参数覆盖
        for (String arg : args) {
            if (arg.startsWith("--target=")) target = arg.substring(9);
            else if (arg.startsWith("--host=")) host = arg.substring(7);
            else if (arg.startsWith("--endpoint=")) endpoint = arg.substring(11);
            else if (arg.startsWith("--resource_id=")) resourceId = arg.substring(14);
            else if (arg.startsWith("--app_key=")) appKey = arg.substring(10);
            else if (arg.startsWith("--access_key=")) accessKey = arg.substring(13);
            else if (arg.startsWith("--audio_file=")) audioFile = arg.substring(13);
            else if (arg.startsWith("--outdir=")) outdir = arg.substring(9);
            else if (arg.startsWith("--chunk_size=")) chunkSize = Integer.parseInt(arg.substring(13));
        }
        String wsUrl = host + "/" + endpoint;
        System.out.println("wsUrl: " + wsUrl);
        final String finalAudioFile = audioFile;
        final int finalChunkSize = chunkSize;
        final String finalOutdir = outdir;
        final BlockingQueue<AstService.TranslateResponse> responseQueue = new LinkedBlockingQueue<>();
        final CountDownLatch latch = new CountDownLatch(1);
        final Object sendStartSignal = new Object();
        final AtomicBoolean handshakeDone = new AtomicBoolean(false);
        final AtomicBoolean sessionEnd = new AtomicBoolean(false);
        final StringBuilder recvText = new StringBuilder();
        final ByteArrayOutputStream recvAudio = new ByteArrayOutputStream();
        final String sessionId = UUID.randomUUID().toString();

        OkHttpClient client = new OkHttpClient();
        String connId = UUID.randomUUID().toString();
        Request request = new Request.Builder()
                .url(wsUrl)
                .addHeader("X-Api-App-Key", appKey)
                .addHeader("X-Api-Access-Key", accessKey)
                .addHeader("X-Api-Resource-Id", resourceId)
                .addHeader("X-Api-Connect-Id", connId)
                .build();

        WebSocket ws = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket webSocket, Response response) {
                System.out.println("WebSocket opened");
                // 发送 StartSession
                AstService.TranslateRequest startReq = AstService.TranslateRequest.newBuilder()
                        .setRequestMeta(Rpcmeta.RequestMeta.newBuilder().setSessionID(sessionId))
                        .setEvent(Events.Type.StartSession)
                        .setUser(AuBase.User.newBuilder().setUid("ast_java_client").setDid("ast_java_client"))
                        .setSourceAudio(AuBase.Audio.newBuilder().setFormat("wav").setRate(16000).setBits(16).setChannel(1))
                        .setTargetAudio(AuBase.Audio.newBuilder().setFormat("ogg_opus").setRate(48000))
                        .setRequest(AstService.ReqParams.newBuilder().setMode("s2s").setSourceLanguage("zh").setTargetLanguage("en"))
                        .build();
                webSocket.send(okio.ByteString.of(startReq.toByteArray()));
                System.out.println("StartSession sent");
                
                // 启动发送线程
                new Thread(() -> {
                    try {
                        // 等待握手响应
                        synchronized (sendStartSignal) {
                            while (!handshakeDone.get() && !sessionEnd.get()) {
                                sendStartSignal.wait(10);
                            }
                        }
                        if (sessionEnd.get()) return;
                        // 分片发送音频
                        FileInputStream fis = new FileInputStream(new File(finalAudioFile));
                        byte[] buffer = new byte[finalChunkSize];
                        int read;
                        while ((read = fis.read(buffer)) != -1 && !sessionEnd.get()) {
                            AstService.TranslateRequest chunkReq = AstService.TranslateRequest.newBuilder()
                                    .setRequestMeta(Rpcmeta.RequestMeta.newBuilder().setSessionID(sessionId))
                                    .setEvent(Events.Type.TaskRequest)
                                    .setSourceAudio(AuBase.Audio.newBuilder().setBinaryData(com.google.protobuf.ByteString.copyFrom(buffer, 0, read)))
                                    .build();
                            webSocket.send(okio.ByteString.of(chunkReq.toByteArray()));
                            System.out.println("Sent chunk: " + read);
                            Thread.sleep(100); // 100ms
                        }
                        fis.close();
                        // 发送 FinishSession
                        if (!sessionEnd.get()) {
                            AstService.TranslateRequest finishReq = AstService.TranslateRequest.newBuilder()
                                    .setRequestMeta(Rpcmeta.RequestMeta.newBuilder().setSessionID(sessionId))
                                    .setEvent(Events.Type.FinishSession)
                                    .build();
                            webSocket.send(okio.ByteString.of(finishReq.toByteArray()));
                            System.out.println("FinishSession sent");
                        }
                    } catch (Exception e) {
                        System.err.println("Send error: " + e);
                        sessionEnd.set(true);
                        latch.countDown();
                    }
                }).start();
            }

            @Override
            public void onMessage(WebSocket webSocket, okio.ByteString bytes) {
                System.out.println("received");
                try {
                    AstService.TranslateResponse resp = AstService.TranslateResponse.parseFrom(bytes.toByteArray());
                    responseQueue.put(resp);
                } catch (Exception e) {
                    System.err.println("Parse error: " + e);
                }
            }

            @Override
            public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                System.err.println("WebSocket error: " + t);
                sessionEnd.set(true);
                latch.countDown();
            }

            @Override
            public void onClosing(WebSocket webSocket, int code, String reason) {
                System.out.println("WebSocket closing: " + code + " " + reason);
                webSocket.close(1000, null);
                sessionEnd.set(true);
                latch.countDown();
            }

            @Override
            public void onClosed(WebSocket webSocket, int code, String reason) {
                System.out.println("WebSocket closed: " + code + " " + reason);
            }
        });

        // 独立接收线程
        new Thread(() -> {
            try {
                while (!sessionEnd.get()) {
                    AstService.TranslateResponse resp = responseQueue.take();
                    int eventType = resp.getEventValue();
                    System.out.println("Received event: " + eventType);
                    if (eventType == Events.Type.SessionStarted.getNumber()) {
                        synchronized (sendStartSignal) {
                            handshakeDone.set(true);
                            sendStartSignal.notifyAll();
                        }
                        System.out.println("Session (ID=" + sessionId + ") started.");
                    } else if (eventType == Events.Type.SessionFailed.getNumber()) {
                        System.out.println("(session_id=" + resp.getResponseMeta().getSessionID() + ") failed, status code:" + resp.getResponseMeta().getStatusCode() + ", error message:" + resp.getResponseMeta().getMessage());
                        sessionEnd.set(true);
                        latch.countDown();
                    } else if (eventType == Events.Type.SessionCanceled.getNumber()) {
                        System.out.println("(session_id=" + resp.getResponseMeta().getSessionID() + ") canceled");
                        sessionEnd.set(true);
                        latch.countDown();
                    } else if (eventType == Events.Type.SessionFinished.getNumber()) {
                        System.out.println("(session_id=" + resp.getResponseMeta().getSessionID() + ") finished");
                        // 保存音频和文本
                         try {
                            if (recvAudio.size() > 0) {
                                String audioPath = finalOutdir + "/v4_translate_audio_" + sessionId + ".opus";
                                Files.write(new File(audioPath).toPath(), recvAudio.toByteArray());
                                System.out.println("Session finished, audio is saved as: " + audioPath);
                                System.out.println("Session finished, text is: " + recvText.toString());
                            } else {
                                System.err.println("Session finished, no audio data is received.");
                            }
                        } catch (Exception e) {
                            System.err.println("Save audio file error: " + e);
                        }
                        sessionEnd.set(true);
                        latch.countDown();
                    } else {
                        if (eventType == Events.Type.UsageResponse.getNumber()){
                            System.out.println("Receive message (session_id=" + resp.getResponseMeta().getSessionID()
                                + ", event=" + eventType + ")," + ", text:" + resp.toString());
                        } else {
                            System.out.println("Receive message (session_id=" + resp.getResponseMeta().getSessionID()
                                + ", event=" + eventType + "), seq:" + resp.getResponseMeta().getSequence()
                                + ", text:" + resp.getText() + ", audio data length:" + resp.getData().size()
                                + ", spk_chg:" + resp.getSpkChg());
                            recvAudio.write(resp.getData().toByteArray());
                            recvText.append(resp.getText());
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println("Receiver error: " + e);
                sessionEnd.set(true);
                latch.countDown();
            }
        }).start();

        latch.await();
        // 关闭 WebSocket 和客户端资源
        ws.close(1000, "Session completed");
        client.dispatcher().executorService().shutdown();
        System.err.println("exit");
    }
} 